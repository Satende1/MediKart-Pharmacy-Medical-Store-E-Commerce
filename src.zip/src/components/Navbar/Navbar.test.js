import { render, screen } from "@testing-library/react";
import Navbar from "./Navbar";

// Mock image imports
jest.mock("../../assets/Medikart-logo.png", () => "logo.png");

describe("Navbar Component", () => {
  test("renders MediKart logo text", () => {
    render(<Navbar />);
    expect(screen.getByText("MediKart")).toBeInTheDocument();
  });

  test("renders navigation links", () => {
    render(<Navbar />);

    expect(screen.getByText("Home")).toBeInTheDocument();
    expect(screen.getByText("Shop")).toBeInTheDocument();
    expect(screen.getByText("Categories")).toBeInTheDocument();
    expect(screen.getByText("About")).toBeInTheDocument();
    expect(screen.getByText("Contact")).toBeInTheDocument();
  });

  test("renders search input", () => {
    render(<Navbar />);

    expect(
      screen.getByPlaceholderText("Search Medicines...")
    ).toBeInTheDocument();
  });

  test("renders user action buttons", () => {
    render(<Navbar />);

    expect(screen.getByText(/Wishlist/i)).toBeInTheDocument();
    expect(screen.getByText(/Cart/i)).toBeInTheDocument();
    expect(screen.getByText(/Login/i)).toBeInTheDocument();
  });

  test("renders mobile menu button", () => {
    render(<Navbar />);

    expect(screen.getByText("☰")).toBeInTheDocument();
  });
});